package com.jims8161.shujichinese.exam;

public class ShujiExamConstants {
	public static final String ACTION_ALARM_DAILY_EXAM = "com.jims8161.shujichinese.exam.daily_exam_alarm";
    public static final String SCHEME = "shujiexam";
    public static final String AUTHORITY = "com.jims8161.shujichinese.exam.daily_exam_alarm";
    public static final int NOTIFICATION_ID_DAILY_EXAM = 0;
    public static final int MEMORIZE_ALARM_DEFAULT_TIME = 9;
}
