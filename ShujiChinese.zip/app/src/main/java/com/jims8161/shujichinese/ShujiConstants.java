package com.jims8161.shujichinese;

public class ShujiConstants {



	//public static final int MAX_DIVISION = 5;



	public static final String EXTRAS_HANZI = "hanzi";
	public static final String EXTRAS_PINYIN = "pinyin";
	public static final String EXTRAS_MEANING = "meaning";

	public static final String ADV_ID = "ca-app-pub-8960156935811974/9838136442";//"a1535b79b2a7c1e"; Legacy
	
	public static final String URL_WORD_LIST = "http://sparr250.iptime.org/www/file/shuji/shujiwordlist.xml";
}
